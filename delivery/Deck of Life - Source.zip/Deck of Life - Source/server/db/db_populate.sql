-- Players
INSERT INTO Player(id_player, display_name, age) VALUES (1, 'Raul', 27);
INSERT INTO Player(id_player, display_name, age) VALUES (2, 'Pedro', 20);
INSERT INTO Player(id_player, display_name, age) VALUES (3, 'Bruno', 60);

-- Users
INSERT INTO PlayerUser(id_player, email, pass) VALUES ( 1, 'raulgrell@gmail.com', 'raulgrell');
INSERT INTO PlayerUser(id_player, email, pass) VALUES ( 2, 'pedro.aca@gmail.com', 'pedro');
INSERT INTO PlayerUser(id_player, email, pass) VALUES ( 3, 'bruno.silva@gmail.com', 'bruno');
